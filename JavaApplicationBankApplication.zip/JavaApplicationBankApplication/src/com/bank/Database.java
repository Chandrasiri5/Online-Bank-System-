
package com.bank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author imesh
 */
public class Database 
        
{
    
    
 String dbusername = "root"; 
 String dbpassword ="Imesh/@1234" ; 
 String dburl = "jdbc:mysql://localhost:3306/bankapplication";
 String dbdriver = "com.mysql.jdbc.Driver";
 Connection dbcon;
   

 void dbConnect() throws ClassNotFoundException, SQLException

 {


 dbcon = DriverManager.getConnection(dburl, dbusername, dbpassword);

 }

 void dbclose() throws SQLException
 {
 dbcon.close();
 }
}