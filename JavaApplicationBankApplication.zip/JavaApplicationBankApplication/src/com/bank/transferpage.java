
package com.bank;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author imesh
 */
public class transferpage extends javax.swing.JFrame {
ResultSet RS,rs2,rs3;
    /**
     * Creates new form transferpage
     */
   String UsernameOfCustomer;
     String PasswordOfCustomer;
    public transferpage(String UsernameOfCustomer,String PasswordOfCustomer) {
        this.UsernameOfCustomer=UsernameOfCustomer;
        this.PasswordOfCustomer=PasswordOfCustomer;
        initComponents();
                     try {

            Database D=new Database();
            Database D2=new Database();
            D.dbConnect();
         
               
            
            String sql="SELECT r2.Balance,r2.acc_number FROM bankapplication.register1 r1,bankapplication.register2 r2 where r1.Username=? and r1.Password=? and r1.account_number=r2.acc_number;";
            
                 
            PreparedStatement pstmt=D.dbcon.prepareStatement(sql);
            
            pstmt.setString(1, UsernameOfCustomer);
             pstmt.setString(2,PasswordOfCustomer);
            RS=pstmt.executeQuery();
            if(RS.next())
            {
                             
                String add2=RS.getString("Balance");
                balance.setText(add2);
                
                String acc_no=RS.getString("acc_number");
                Sender_Account_no.setText(acc_no);
                
                RS.close();
                pstmt.close();

            }
            else{
                JOptionPane.showMessageDialog(null,"Enter the Correct account number\n or pin");
            }

        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Accountnumber1label = new javax.swing.JLabel();
        Sender_Account_no = new javax.swing.JTextField();
        Amttranslabel = new javax.swing.JLabel();
        revceiver_account_number = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jLabel3 = new javax.swing.JLabel();
        withdraw = new javax.swing.JTextField();
        Accountnumber1label1 = new javax.swing.JLabel();
        balance = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));

        jLabel1.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("TRANSFER MONEY");
        jLabel1.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(204, 0, 0)));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(182, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(151, 151, 151))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        Accountnumber1label.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        Accountnumber1label.setForeground(new java.awt.Color(255, 255, 255));
        Accountnumber1label.setText("SENDER'S ACCOUNT NUMBER");

        Sender_Account_no.setEditable(false);

        Amttranslabel.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        Amttranslabel.setForeground(new java.awt.Color(255, 255, 255));
        Amttranslabel.setText("AMOUNT TO BE TRANSFERED");

        jToggleButton1.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jToggleButton1.setText("TRANSFER");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("RECEIVER'S ACCOUNT NUMBER");

        Accountnumber1label1.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        Accountnumber1label1.setForeground(new java.awt.Color(255, 255, 255));
        Accountnumber1label1.setText("BALANCE IN YOUR ACCOUNT");

        balance.setEditable(false);

        jButton2.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 1, 14)); // NOI18N
        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(48, 48, 48))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Accountnumber1label)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(25, 25, 25)
                                        .addComponent(jLabel2))
                                    .addComponent(jLabel3)
                                    .addComponent(Amttranslabel)
                                    .addComponent(Accountnumber1label1))
                                .addGap(48, 48, 48)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(withdraw, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(balance, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Sender_Account_no, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                                    .addComponent(revceiver_account_number)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addGap(32, 32, 32)
                                        .addComponent(jToggleButton1))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jButton2)
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Accountnumber1label)
                    .addComponent(Sender_Account_no, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Accountnumber1label1)
                    .addComponent(balance, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(withdraw, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Amttranslabel))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(revceiver_account_number, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addComponent(jToggleButton1)
                .addContainerGap(92, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(704, 537));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
    try {

        String acount_no_of_sender=Sender_Account_no.getText();
        
        String balance_1=balance.getText();
        String wthdraw_1=withdraw.getText();
//        System.out.println(acount_no_of_sender+"--"+balance_1+"--"+wthdraw_1);
        String receiver=revceiver_account_number.getText();
        float bal=Float.valueOf(balance_1);
        float with=Float.valueOf(wthdraw_1);
        float depo=Float.valueOf(receiver);
        
//        System.out.println(bal+"--"+with+"--"+depo);
        Database D=new Database();
        D.dbConnect();
        if(with<bal&&with>0)
        {
            float sum=Float.parseFloat(balance_1)-Float.parseFloat(wthdraw_1);
            String total=String.valueOf(sum);
            
            String withdrawing="Update register2 set Balance='"+total+"'where acc_number='"+acount_no_of_sender+"'";
            PreparedStatement pstmt=D.dbcon.prepareStatement(withdrawing);
            pstmt.executeUpdate();
            
            String receiver_sql="Select *from register2 where acc_number='"+receiver+"'";
            PreparedStatement pstmt_of_receiver=D.dbcon.prepareStatement(receiver_sql);
            rs2=pstmt_of_receiver.executeQuery();
            if(rs2.next())
            {
            String balance_of_reciever=rs2.getString("Balance");
            
            
            float sum_of_receiver=Float.parseFloat(balance_of_reciever)+Float.parseFloat(wthdraw_1);
            String total_of_receiver=String.valueOf(sum_of_receiver);
            
            String deposit="Update register2 set Balance='"+total_of_receiver+"'where acc_number='"+receiver+"'";
            PreparedStatement pstmt_final=D.dbcon.prepareStatement(deposit);
            pstmt_final.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"The Money Has been Successfully Transferred");

            }
            else
            {
                JOptionPane.showMessageDialog(null,"Amount Not Transferred");
            }
            }
     
        else
                {
                    
           JOptionPane.showMessageDialog(null,"Amount is Exceeding");
        
        }
    
    
    
    
    
    
    
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(transferpage.class.getName()).log(Level.SEVERE, null, ex);
    } catch (SQLException ex) {
        Logger.getLogger(transferpage.class.getName()).log(Level.SEVERE, null, ex);
    };
       
        
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        viewingcustomerpage v=new viewingcustomerpage(UsernameOfCustomer,PasswordOfCustomer);
        v.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(transferpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(transferpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(transferpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(transferpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new transferpage("Joslin","1234").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Accountnumber1label;
    private javax.swing.JLabel Accountnumber1label1;
    private javax.swing.JLabel Amttranslabel;
    private javax.swing.JTextField Sender_Account_no;
    private javax.swing.JTextField balance;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JTextField revceiver_account_number;
    private javax.swing.JTextField withdraw;
    // End of variables declaration//GEN-END:variables
}
